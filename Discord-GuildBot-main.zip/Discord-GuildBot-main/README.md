Download this
Then open terminal in vsc, and run "npm install"
Then go to "config.json" and put ur info! Remember to remove the // and whatever it says after
Then save it. 
Then do "node ." in the terminal
Enjoy!
